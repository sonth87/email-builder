import { defineConfig } from "vite";
import react from "@vitejs/plugin-react-swc";
import tsconfigPaths from "vite-tsconfig-paths";
import { resolve } from "path";
import commonjs from "vite-plugin-commonjs";

export default defineConfig({
  plugins: [
    commonjs({
      // Tự động xử lý các module CommonJS
      filter: (id) => id.includes("node_modules"),
    }),
    react(),
    tsconfigPaths(),
  ],
  resolve: {
    preserveSymlinks: true, // Quan trọng cho workspace packages
    alias: {
      // Define aliases for each local package
      "@core-builder/block-avatar": resolve(
        __dirname,
        "../../packages/block-avatar"
      ),
      "@core-builder/block-button": resolve(
        __dirname,
        "../../packages/block-button"
      ),
      "@core-builder/block-columns-container": resolve(
        __dirname,
        "../../packages/block-columns-container"
      ),
      "@core-builder/block-container": resolve(
        __dirname,
        "../../packages/block-container"
      ),
      "@core-builder/block-divider": resolve(
        __dirname,
        "../../packages/block-divider"
      ),
      "@core-builder/block-heading": resolve(
        __dirname,
        "../../packages/block-heading"
      ),
      "@core-builder/block-html": resolve(
        __dirname,
        "../../packages/block-html"
      ),
      "@core-builder/block-image": resolve(
        __dirname,
        "../../packages/block-image"
      ),
      "@core-builder/block-spacer": resolve(
        __dirname,
        "../../packages/block-spacer"
      ),
      "@core-builder/block-text": resolve(
        __dirname,
        "../../packages/block-text"
      ),
      "@core-builder/document-core": resolve(
        __dirname,
        "../../packages/document-core"
      ),
      "@core-builder/email-builder": resolve(
        __dirname,
        "../../packages/email-builder"
      ),
    },
  },
  optimizeDeps: {
    include: [
      // Force Vite to pre-bundle these dependencies
      "@core-builder/block-avatar",
      "@core-builder/block-button",
      "@core-builder/block-columns-container",
      "@core-builder/block-container",
      "@core-builder/block-divider",
      "@core-builder/block-heading",
      "@core-builder/block-html",
      "@core-builder/block-image",
      "@core-builder/block-spacer",
      "@core-builder/block-text",
      "@core-builder/document-core",
      "@core-builder/email-builder",
      // Add MUI related packages
      "react-is", // Thêm react-is vì MUI phụ thuộc vào nó
      "prop-types",
      "@mui/utils",
      "@mui/material",
      "@mui/system",
      "@emotion/react",
      "@emotion/styled",
    ],
    esbuildOptions: {
      mainFields: ["module", "main", "browser"],
    },
  },
  build: {
    commonjsOptions: {
      transformMixedEsModules: true,
      include: [/node_modules/, /packages/],
    },
  },
});
